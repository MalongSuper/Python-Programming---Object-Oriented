# General/FloorPlanElement.py

class FloorPlanElement:
    category = "Undefined"
    description = "Undefined"

    def __init__(self, x, y, width, height, parent):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.parent = parent  # the component inside the parent

    def move_to(self, x, y):
        self.x = x
        self.y = y

    def print_category(self):
        print(self.category)

    def print_description(self):
        print(self.description)

    def draw(self):
        print("Category:", end=" ")
        self.print_category()
        print("Description:", end=" ")
        self.print_description()
        print(f"X: {str(self.x)}, Y: {str(self.y)}. "
              f"Width: {str(self.width)}, Height: {str(self.height)}")
