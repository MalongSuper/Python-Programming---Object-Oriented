from Build.Areas import *
from Build.Rooms import *
from Build.Doors import *
from Build.Windows import *
from Decorate.Electronics import *
from Furnish.Bedroom.Beds import *
from Furnish.Bedroom.KidsBeds import *
from Furnish.Bathroom import *
from Furnish.Kitchen import *
from Furnish.DiningRoom import *
from Furnish.Livingroom import *
from Furnish.Office import *
from Furnish.LaundryandUtility import *
from Landscape.AreasDefinition import *
from Landscape.TreesandPlants import *
from Outdoor.Structures import *


def main():
    # House shape
    house = MediumHouse(800, 450, None)
    house.draw()
    # Create a simple bedroom
    bedroom1 = SquareRoom(100, 200, 180, None)
    door1 = EntryDoor(100, 1, 50, 5, bedroom1)
    window1 = Window(120, 120, 15, 15, bedroom1)
    bed1 = FabricBed(130, 230, 120, 110, bedroom1)
    bed2 = KidBed(145, 145, 230, 120, bedroom1)
    bedroom1.draw()
    door1.draw()
    window1.draw()
    bed1.draw()
    bed2.draw()
    # Bathroom
    bathroom1 = Bathroom(100, 200, 190, 170, None)
    bathroom1.draw()
    # Kitchen
    kitchen1 = Kitchen(120, 250, 180, 170, None)
    kitchen1.draw()
    diningroom1 = Bathroom(112, 250, 180, 170, kitchen1)
    diningroom1.draw()
    # Living Room
    livingroom1 = LivingRoom(113, 123, 190, 190, None)
    livingroom1.draw()
    office = Office(112, 123, 130, 190, livingroom1)
    office.draw()
    laundry = Laundry(112, 114, 120, 140, None)
    laundry.draw()
    # Landscape
    landscape_area = LandscapeArea(123, 135, None)
    landscape_area.draw()
    landscape_plant = Plants(123, 134, landscape_area)
    landscape_plant.draw()
    # Additional
    router = Router(123, 123, livingroom1)
    router.draw()


if __name__ == '__main__':
    main()
