from General.FloorPlanElement import FloorPlanElement


class LandscapeArea(FloorPlanElement):
    def __init__(self, height, width, parent):
        super().__init__(None, None, height, width, parent)
    category = "Landscape Area"
