from General.FloorPlanElement import FloorPlanElement


class Tree(FloorPlanElement):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    category = "Tree"


class Plants(FloorPlanElement):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    category = "Plants"
