from General.FloorPlanElement import FloorPlanElement


class Material(FloorPlanElement):
    def __init__(self, parent):
        super().__init__(None, None, None, None, parent)
    category = "Material"


class LanscapeMaterialWood(Material):
    description = "Wood"


class LanscapeMaterialSoil(Material):
    description = "Soil"
