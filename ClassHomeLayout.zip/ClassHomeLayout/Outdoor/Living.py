from General.FloorPlanElement import FloorPlanElement


class Living(FloorPlanElement):
    def __init__(self, parent):
        super().__init__(None, None, None, None, parent)
    category = "Living"
    description = "Basic"


class ModernLiving(Living):
    description = "Modern"


class WealthyLiving(Living):
    description = "Wealthy"
