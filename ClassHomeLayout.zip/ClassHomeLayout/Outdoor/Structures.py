from General.FloorPlanElement import FloorPlanElement


class Structure(FloorPlanElement):
    def __init__(self, height, width, parent):
        super().__init__(None, None, height, width, parent)
    category = "Structure"


class TinyHouse(Structure):
    description = "Tiny House"


class MediumHouse(Structure):
    description = "Medium House"


class MobileHouse(Structure):
    description = "Mobile House"


class Apartment(Structure):
    description = "Apartment"
