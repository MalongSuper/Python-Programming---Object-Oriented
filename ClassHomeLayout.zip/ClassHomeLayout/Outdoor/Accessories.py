from General.FloorPlanElement import FloorPlanElement


class Accessories(FloorPlanElement):
    def __init__(self, parent):
        super().__init__(None, None, None, None, parent)
    category = "Accessories"
    description = "Basic"


class Christmas(Accessories):
    description = "Christmas"


class Halloween(Accessories):
    description = "Halloween"
