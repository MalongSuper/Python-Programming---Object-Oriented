from General.FloorPlanElement import FloorPlanElement


class Kitchen(FloorPlanElement):
    category = 'Bathroom'
    description = "Kitchen Facilities"
