from General.FloorPlanElement import FloorPlanElement


class Laundry(FloorPlanElement):
    category = 'Laundry'
    description = "Laundry Facilities"


class Utility(FloorPlanElement):
    category = 'Utility'
    description = "Utility Facilities"
