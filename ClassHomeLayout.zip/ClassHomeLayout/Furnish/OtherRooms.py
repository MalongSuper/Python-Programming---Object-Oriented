from General.FloorPlanElement import FloorPlanElement


class OtherRooms(FloorPlanElement):
    category = "Other"
