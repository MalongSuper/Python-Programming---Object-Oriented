from General.FloorPlanElement import FloorPlanElement


class LivingRoom(FloorPlanElement):
    category = 'Dining Room'
    description = "Living Room Facilities"
