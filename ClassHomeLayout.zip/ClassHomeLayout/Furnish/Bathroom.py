from General.FloorPlanElement import FloorPlanElement


class Bathroom(FloorPlanElement):
    category = 'Bathroom'
    description = "Bathroom Facilities"
