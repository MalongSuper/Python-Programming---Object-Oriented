from General.FloorPlanElement import FloorPlanElement


class Office(FloorPlanElement):
    category = 'Office Room'
    description = "Office Room Facilities"
