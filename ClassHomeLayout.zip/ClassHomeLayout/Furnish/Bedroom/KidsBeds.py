from General.FloorPlanElement import FloorPlanElement


class KidBed(FloorPlanElement):
    category = "KidBed"
    description = "Generic bed"
