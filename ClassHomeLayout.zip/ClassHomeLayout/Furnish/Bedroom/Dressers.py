from General.FloorPlanElement import FloorPlanElement


class Dresser(FloorPlanElement):
    category = "Dresser"
