from General.FloorPlanElement import FloorPlanElement


class Nursery(FloorPlanElement):
    category = 'Nursery'
