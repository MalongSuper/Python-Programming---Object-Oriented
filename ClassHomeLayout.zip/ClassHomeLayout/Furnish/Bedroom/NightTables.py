from General.FloorPlanElement import FloorPlanElement


class Table(FloorPlanElement):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    category = "Table"


class WorkingTable(Table):
    description = "Working Table + Chair"


class StudyTable(Table):
    description = "Studying Table + Chair"
