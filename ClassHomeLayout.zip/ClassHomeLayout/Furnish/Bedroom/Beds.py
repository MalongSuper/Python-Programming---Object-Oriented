from General.FloorPlanElement import FloorPlanElement


class Bed(FloorPlanElement):
    category = "Bed"
    description = "Generic bed"


class FabricBed(Bed):
    description = "Fabric bed"
