from General.FloorPlanElement import FloorPlanElement


class DiningRoom(FloorPlanElement):
    category = 'Dining Room'
    description = "Dining Room Facilities"
