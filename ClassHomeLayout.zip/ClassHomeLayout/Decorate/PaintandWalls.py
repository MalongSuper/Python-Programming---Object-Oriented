from General.FloorPlanElement import FloorPlanElement


class Paint(FloorPlanElement):
    category = "Paint"


class PaintHouse(Paint):
    description = "House"

    def __init__(self, parent, color="black"):
        super().__init__(None, None, None, None, parent)
        self.color = color

    def paint(self):
        print(f"Color {self.color}")


class PaintWall(Paint):
    description = "Wall"

    def __init__(self, parent, color="black"):
        super().__init__(None, None, None, None, parent)
        self.color = color

    def paint(self):
        print(f"Color {self.color}")
