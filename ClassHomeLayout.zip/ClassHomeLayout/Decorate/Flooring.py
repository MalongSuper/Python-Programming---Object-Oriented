from General.FloorPlanElement import FloorPlanElement


class Floor(FloorPlanElement):
    def __init__(self, parent):
        super().__init__(None, None, None, None, parent)
    category = "Floor"


class LaminateFloor(Floor):
    description = "Laminate Floor"


class WoodenFloor(Floor):
    description = "Wooden Floor"
