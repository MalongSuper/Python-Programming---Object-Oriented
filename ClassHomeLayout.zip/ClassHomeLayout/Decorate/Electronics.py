from General.FloorPlanElement import FloorPlanElement


class Electronic(FloorPlanElement):
    category = "Electronic"


class Router(Electronic):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    description = "Wi-Fi Router"


class SwitchBoard(Electronic):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    description = "Switch Board"
