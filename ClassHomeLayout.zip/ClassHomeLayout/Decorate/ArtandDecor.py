from General.FloorPlanElement import FloorPlanElement


class Art(FloorPlanElement):
    category = "Art"
    description = "General Art"


class RandomArt(Art):
    description = "Renaissance Art"


class RenownArt(Art):
    description = "Renown Art"


class Decoration(FloorPlanElement):
    def __init__(self, parent):
        super().__init__(None, None, None, None, parent)
    category = "Decoration"
    description = "Blank Decoration"


class FlowerDecor(Decoration):
    description = "Flower Decoration"


class PolkaDotDecor(Decoration):
    description = "Polka Dot Decoration"


class StripeDecor(Decoration):
    description = "Stripe Decoration"
