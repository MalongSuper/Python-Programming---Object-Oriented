from General.FloorPlanElement import FloorPlanElement


class CounterTop(FloorPlanElement):
    def __init__(self, parent):
        super().__init__(None, None, None, None, parent)
    category = "Counter Top"
    description = "Modern"


class Wood(CounterTop):
    description = "Wood"
