from General.FloorPlanElement import FloorPlanElement


class Light(FloorPlanElement):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    category = "Light"


class CeilingLight(Light):
    description = "Ceiling Light"


class Lamb(Light):
    description = "Lamb"


class Fan(FloorPlanElement):
    def __init__(self, x, y, parent):
        super().__init__(x, y, None, None, parent)
    category = "Fan"


class CeilingFan(Fan):
    description = "Ceiling Fan"


class StandingFan(Fan):
    description = "Standing Fan"


class WallFan(Fan):
    description = "Wall Fan"
